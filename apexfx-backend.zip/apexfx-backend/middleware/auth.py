"""
APEX FX — Auth Middleware
JWT verification injected before every protected route
"""
import jwt
import hashlib
import logging
from flask import request, g, current_app, jsonify
from functools import wraps
from datetime import datetime, timezone
from database import query

logger = logging.getLogger(__name__)


def auth_middleware(app):
    """Register before_request hook for JWT extraction."""
    @app.before_request
    def extract_user():
        g.user = None
        g.user_id = None

        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return  # Not authenticated — public routes still work

        token = auth_header[7:]
        try:
            payload = jwt.decode(
                token,
                current_app.config["JWT_SECRET"],
                algorithms=[current_app.config["JWT_ALGORITHM"]],
            )
        except jwt.ExpiredSignatureError:
            return  # Will fail on protected routes
        except jwt.InvalidTokenError:
            return

        # Check blacklist
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        bl = query(
            "SELECT 1 FROM blacklisted_tokens WHERE token_hash = ?",
            (token_hash,), one=True
        )
        if bl:
            return  # Revoked

        # Load user
        user = query(
            "SELECT id, name, email, role, lang, is_active, is_banned FROM users WHERE id = ?",
            (payload.get("sub"),), one=True
        )
        if user and user["is_active"] and not user["is_banned"]:
            g.user = user
            g.user_id = user["id"]

    @app.teardown_appcontext
    def teardown_db(e=None):
        from database import close_db
        close_db(e)


# ── Decorators ────────────────────────────────────────────────

def require_auth(f):
    """Protect a route — requires valid JWT."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not g.get("user"):
            return jsonify({"error": "Unauthorized", "message": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated


def require_admin(f):
    """Protect a route — requires admin role."""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = g.get("user")
        if not user:
            return jsonify({"error": "Unauthorized", "message": "Authentication required"}), 401
        if user["role"] != "admin":
            return jsonify({"error": "Forbidden", "message": "Admin access required"}), 403
        return f(*args, **kwargs)
    return decorated


def optional_auth(f):
    """Route works for both authenticated and anonymous users."""
    @wraps(f)
    def decorated(*args, **kwargs):
        return f(*args, **kwargs)
    return decorated


def generate_tokens(user_id: str, config) -> dict:
    """Generate access + refresh JWT pair."""
    import secrets
    from datetime import timedelta

    now = datetime.now(timezone.utc)

    access_payload = {
        "sub": user_id,
        "iat": now,
        "exp": now + timedelta(seconds=config["JWT_ACCESS_EXPIRES"]),
        "type": "access",
        "jti": secrets.token_hex(16),
    }

    refresh_payload = {
        "sub": user_id,
        "iat": now,
        "exp": now + timedelta(seconds=config["JWT_REFRESH_EXPIRES"]),
        "type": "refresh",
        "jti": secrets.token_hex(16),
    }

    access_token  = jwt.encode(access_payload,  config["JWT_SECRET"], algorithm=config["JWT_ALGORITHM"])
    refresh_token = jwt.encode(refresh_payload, config["JWT_SECRET"], algorithm=config["JWT_ALGORITHM"])

    return {
        "access_token":  access_token,
        "refresh_token": refresh_token,
        "expires_in":    config["JWT_ACCESS_EXPIRES"],
        "token_type":    "Bearer",
    }


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()
