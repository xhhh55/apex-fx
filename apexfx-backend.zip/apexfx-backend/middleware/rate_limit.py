"""
APEX FX — Rate Limiter
In-memory sliding window rate limiter per IP
"""
import time
import threading
import logging
from collections import defaultdict, deque
from flask import request, jsonify, g

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_windows: dict = defaultdict(deque)


def rate_limiter(app):
    @app.before_request
    def check_rate_limit():
        ip = request.remote_addr or "unknown"
        path = request.path
        now = time.time()

        if "/api/auth/" in path:
            limit, window = app.config.get("RATE_LIMIT_AUTH", 10), 60
        else:
            limit, window = app.config.get("RATE_LIMIT_GLOBAL", 300), 60

        key = f"{ip}:{path.split('/')[2] if len(path.split('/')) > 2 else 'global'}"

        with _lock:
            dq = _windows[key]
            while dq and dq[0] < now - window:
                dq.popleft()
            if len(dq) >= limit:
                return jsonify({
                    "error": "Too Many Requests",
                    "message": f"Rate limit: {limit} req/{window}s",
                    "retry_after": int(window - (now - dq[0])) if dq else window,
                }), 429
            dq.append(now)

