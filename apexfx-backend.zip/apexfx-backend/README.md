# APEX FX — Backend API

**Flask + SQLite + JWT | Python 3.12**

## Quick Start

```bash
cd apexfx-backend
python app.py
# Server: http://localhost:5000
# Docs:   http://localhost:5000/api/docs
```

---

## Architecture

```
apexfx-backend/
├── app.py                 # Entry point & app factory
├── config.py              # All configuration
├── database.py            # SQLite schema + helpers
├── requirements.txt
│
├── api/
│   ├── auth.py            # Register, Login, Logout, Refresh, Me
│   ├── users.py           # Profile, Preferences, Stats
│   ├── favorites.py       # CRUD favorites
│   ├── alerts.py          # Price alerts + trigger check
│   ├── portfolio.py       # Virtual trading system
│   ├── reviews.py         # Broker reviews + likes
│   ├── prices.py          # Live prices (ECB cache)
│   ├── brokers.py         # Broker data
│   ├── news.py            # News + economic calendar
│   ├── analytics.py       # Market stats + rankings
│   └── admin.py           # Admin panel
│
├── middleware/
│   ├── auth.py            # JWT middleware + decorators
│   └── rate_limit.py      # Sliding window rate limiter
│
└── utils/
    ├── helpers.py         # now_iso(), audit(), paginate()
    ├── validators.py      # Email, password validation
    └── scheduler.py       # Background thread (prices + alerts)
```

---

## Database Schema (SQLite)

| Table               | Purpose                          |
|---------------------|----------------------------------|
| `users`             | User accounts + roles            |
| `sessions`          | JWT sessions                     |
| `blacklisted_tokens`| Revoked tokens                   |
| `favorites`         | User favorite brokers            |
| `alerts`            | Price alerts                     |
| `portfolios`        | Virtual portfolio balance        |
| `trades`            | Open & closed virtual trades     |
| `reviews`           | Broker reviews                   |
| `review_likes`      | Review like/unlike               |
| `price_history`     | 7-day price snapshots            |
| `user_preferences`  | Per-user settings                |
| `audit_log`         | All user actions                 |

---

## API Endpoints

### Auth
| Method | Endpoint                | Auth | Description         |
|--------|-------------------------|------|---------------------|
| POST   | `/api/auth/register`    | —    | Register new user   |
| POST   | `/api/auth/login`       | —    | Login → JWT tokens  |
| POST   | `/api/auth/logout`      | 🔒   | Invalidate token    |
| POST   | `/api/auth/refresh`     | —    | Refresh access token|
| GET    | `/api/auth/me`          | 🔒   | Current user info   |
| PUT    | `/api/auth/password`    | 🔒   | Change password     |

### Users
| Method | Endpoint                  | Auth | Description      |
|--------|---------------------------|------|------------------|
| GET    | `/api/users/profile`      | 🔒   | Get profile      |
| PUT    | `/api/users/profile`      | 🔒   | Update profile   |
| GET    | `/api/users/preferences`  | 🔒   | Get preferences  |
| PUT    | `/api/users/preferences`  | 🔒   | Update prefs     |
| GET    | `/api/users/stats`        | 🔒   | User statistics  |
| DELETE | `/api/users/account`      | 🔒   | Delete account   |

### Favorites
| Method | Endpoint                     | Auth | Description        |
|--------|------------------------------|------|--------------------|
| GET    | `/api/favorites`             | 🔒   | List favorites     |
| POST   | `/api/favorites`             | 🔒   | Add favorite       |
| DELETE | `/api/favorites/:broker_id`  | 🔒   | Remove favorite    |

### Price Alerts
| Method | Endpoint               | Auth | Description         |
|--------|------------------------|------|---------------------|
| GET    | `/api/alerts`          | 🔒   | List alerts         |
| POST   | `/api/alerts`          | 🔒   | Create alert        |
| PUT    | `/api/alerts/:id`      | 🔒   | Update alert        |
| DELETE | `/api/alerts/:id`      | 🔒   | Delete alert        |
| POST   | `/api/alerts/check`    | —    | Trigger check       |

### Virtual Portfolio
| Method | Endpoint                        | Auth | Description        |
|--------|---------------------------------|------|--------------------|
| GET    | `/api/portfolio`                | 🔒   | Summary + trades   |
| GET    | `/api/portfolio/trades`         | 🔒   | Open trades        |
| POST   | `/api/portfolio/trades`         | 🔒   | Open trade         |
| DELETE | `/api/portfolio/trades/:id`     | 🔒   | Close trade        |
| GET    | `/api/portfolio/history`        | 🔒   | Closed trades      |
| GET    | `/api/portfolio/stats`          | 🔒   | Performance stats  |
| POST   | `/api/portfolio/reset`          | 🔒   | Reset to $100K     |

### Reviews
| Method | Endpoint                      | Auth | Description     |
|--------|-------------------------------|------|-----------------|
| GET    | `/api/reviews/:broker_id`     | —    | Get reviews     |
| POST   | `/api/reviews/:broker_id`     | 🔒   | Submit review   |
| PUT    | `/api/reviews/:id/edit`       | 🔒   | Edit review     |
| DELETE | `/api/reviews/:id`            | 🔒   | Delete review   |
| POST   | `/api/reviews/:id/like`       | 🔒   | Like/unlike     |

### Prices
| Method | Endpoint                  | Auth | Description         |
|--------|---------------------------|------|---------------------|
| GET    | `/api/prices`             | —    | All 10 pairs        |
| GET    | `/api/prices/:pair`       | —    | Single pair         |
| GET    | `/api/prices/history`     | —    | 24h history         |

### Brokers / News / Analytics
| Method | Endpoint                   | Description              |
|--------|----------------------------|--------------------------|
| GET    | `/api/brokers`             | All brokers              |
| GET    | `/api/brokers/:id`         | Broker detail            |
| GET    | `/api/brokers/search?q=`   | Search brokers           |
| GET    | `/api/news`                | Latest news              |
| GET    | `/api/news/calendar`       | Economic calendar        |
| GET    | `/api/analytics/market`    | Market stats             |
| GET    | `/api/analytics/rankings`  | Broker rankings          |

### Admin (🔑 admin role)
| Method | Endpoint                      | Description     |
|--------|-------------------------------|-----------------|
| GET    | `/api/admin/stats`            | System stats    |
| GET    | `/api/admin/users`            | All users       |
| PUT    | `/api/admin/users/:id/ban`    | Ban/unban user  |

---

## Authentication

All protected routes require:
```
Authorization: Bearer <access_token>
```

**Register:**
```json
POST /api/auth/register
{
  "name": "Ahmed Ali",
  "email": "ahmed@example.com",
  "password": "mypassword",
  "lang": "ar"
}
```

**Login response:**
```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "expires_in": 86400,
  "token_type": "Bearer",
  "user": { "id": "u_...", "name": "Ahmed Ali", "email": "...", "role": "user" }
}
```

---

## Background Scheduler

Runs automatically in daemon thread every **30 seconds**:
1. 🔄 Refresh prices from ECB (Frankfurter API)
2. 🔔 Check all active alerts against current prices
3. 🧹 Hourly: Clean expired tokens + old price history (>7 days)

---

## Security Features

- **PBKDF2** password hashing (310,000 iterations — OWASP standard)
- **JWT** access + refresh token pair
- **Token blacklist** on logout
- **Rate limiting**: 10 req/min (auth), 300 req/min (global) per IP
- **Input validation** on all endpoints
- **Audit log** for all sensitive actions
- **CORS** headers on all responses

---

## Default Admin Account
```
Email:    admin@apexfx.com
Password: admin123
Role:     admin
```
> Change password immediately in production!

---

## Connecting the React Frontend

Update your React app's API calls:

```javascript
const API = "http://localhost:5000/api";

// Login
const res = await fetch(`${API}/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, password })
});
const { access_token, user } = await res.json();

// Authenticated request
const prices = await fetch(`${API}/prices`, {
  headers: { Authorization: `Bearer ${access_token}` }
});
```
