"""
APEX FX — Database Layer
SQLite with full schema: users, sessions, favorites,
alerts, portfolio, reviews, price_history
"""
import sqlite3
import os
import logging
from flask import g, current_app

logger = logging.getLogger(__name__)


def get_db():
    """Get thread-local database connection."""
    if "db" not in g:
        db_path = current_app.config["DATABASE_PATH"]
        g.db = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
        g.db.execute("PRAGMA synchronous=NORMAL")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create all tables and seed initial data."""
    from flask import current_app
    db_path = current_app.config["DATABASE_PATH"]

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")

    cur = conn.cursor()

    # ── USERS ──────────────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id          TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        email       TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password    TEXT NOT NULL,
        role        TEXT NOT NULL DEFAULT 'user',
        lang        TEXT NOT NULL DEFAULT 'ar',
        avatar      TEXT,
        bio         TEXT,
        is_active   INTEGER NOT NULL DEFAULT 1,
        is_banned   INTEGER NOT NULL DEFAULT 0,
        created_at  TEXT NOT NULL,
        updated_at  TEXT NOT NULL,
        last_login  TEXT
    )""")

    # ── SESSIONS (JWT blacklist + refresh tokens) ──────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        id          TEXT PRIMARY KEY,
        user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token_hash  TEXT NOT NULL,
        device      TEXT,
        ip          TEXT,
        expires_at  TEXT NOT NULL,
        created_at  TEXT NOT NULL,
        revoked     INTEGER NOT NULL DEFAULT 0
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS blacklisted_tokens (
        token_hash  TEXT PRIMARY KEY,
        revoked_at  TEXT NOT NULL
    )""")

    # ── FAVORITES ──────────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS favorites (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        broker_id   INTEGER NOT NULL,
        broker_name TEXT NOT NULL,
        added_at    TEXT NOT NULL,
        UNIQUE(user_id, broker_id)
    )""")

    # ── PRICE ALERTS ───────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        pair            TEXT NOT NULL,
        target_price    REAL NOT NULL,
        direction       TEXT NOT NULL CHECK(direction IN ('above','below')),
        is_triggered    INTEGER NOT NULL DEFAULT 0,
        triggered_price REAL,
        triggered_at    TEXT,
        note            TEXT,
        created_at      TEXT NOT NULL,
        updated_at      TEXT NOT NULL
    )""")

    # ── VIRTUAL PORTFOLIO ──────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS portfolios (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
        balance     REAL NOT NULL DEFAULT 100000.0,
        equity      REAL NOT NULL DEFAULT 100000.0,
        created_at  TEXT NOT NULL,
        updated_at  TEXT NOT NULL
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS trades (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        pair        TEXT NOT NULL,
        direction   TEXT NOT NULL CHECK(direction IN ('buy','sell')),
        lots        REAL NOT NULL,
        entry_price REAL NOT NULL,
        exit_price  REAL,
        stop_loss   REAL,
        take_profit REAL,
        pip_value   REAL NOT NULL DEFAULT 10.0,
        margin      REAL NOT NULL DEFAULT 0.0,
        profit_loss REAL,
        status      TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed')),
        opened_at   TEXT NOT NULL,
        closed_at   TEXT
    )""")

    # ── REVIEWS ────────────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS reviews (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        broker_id   INTEGER NOT NULL,
        rating      INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        title       TEXT,
        body        TEXT NOT NULL,
        lang        TEXT NOT NULL DEFAULT 'ar',
        likes       INTEGER NOT NULL DEFAULT 0,
        is_approved INTEGER NOT NULL DEFAULT 1,
        created_at  TEXT NOT NULL,
        updated_at  TEXT NOT NULL,
        UNIQUE(user_id, broker_id)
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS review_likes (
        user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        review_id   INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
        PRIMARY KEY (user_id, review_id)
    )""")

    # ── PRICE HISTORY ──────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS price_history (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        pair        TEXT NOT NULL,
        price       REAL NOT NULL,
        bid         REAL,
        ask         REAL,
        pct_change  REAL,
        source      TEXT NOT NULL DEFAULT 'ecb',
        recorded_at TEXT NOT NULL
    )""")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_ph_pair_time ON price_history(pair, recorded_at)")

    # ── USER PREFERENCES ───────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS user_preferences (
        user_id             TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        lang                TEXT NOT NULL DEFAULT 'ar',
        theme               TEXT NOT NULL DEFAULT 'dark',
        default_lot_size    REAL NOT NULL DEFAULT 0.1,
        default_pair        TEXT NOT NULL DEFAULT 'EUR/USD',
        notifications       INTEGER NOT NULL DEFAULT 1,
        email_alerts        INTEGER NOT NULL DEFAULT 0,
        show_welcome        INTEGER NOT NULL DEFAULT 1,
        updated_at          TEXT NOT NULL
    )""")

    # ── AUDIT LOG ──────────────────────────────────────────────
    cur.execute("""
    CREATE TABLE IF NOT EXISTS audit_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT REFERENCES users(id) ON DELETE SET NULL,
        action      TEXT NOT NULL,
        entity      TEXT,
        entity_id   TEXT,
        details     TEXT,
        ip          TEXT,
        created_at  TEXT NOT NULL
    )""")

    # ── Indexes ────────────────────────────────────────────────
    cur.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user  ON sessions(user_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites(user_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_alerts_user    ON alerts(user_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_user    ON trades(user_id, status)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_reviews_broker ON reviews(broker_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_user     ON audit_log(user_id)")

    conn.commit()

    # ── Seed admin user ────────────────────────────────────────
    existing = conn.execute("SELECT id FROM users WHERE email='admin@apexfx.com'").fetchone()
    if not existing:
        import hashlib, secrets
        from datetime import datetime, timezone
        uid = "admin_" + secrets.token_hex(6)
        now = datetime.now(timezone.utc).isoformat()
        # Simple hash for seed (will be bcrypt in production handler)
        pw = hashlib.sha256(("admin123" + uid).encode()).hexdigest()
        conn.execute("""
            INSERT INTO users (id, name, email, password, role, lang, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (uid, "APEX Admin", "admin@apexfx.com", pw, "admin", "en", now, now))
        conn.execute("""
            INSERT INTO user_preferences (user_id, updated_at) VALUES (?, ?)
        """, (uid, now))
        conn.commit()
        logger.info(f"✅ Admin user seeded: admin@apexfx.com / admin123")

    conn.close()
    logger.info("✅ Database schema ready")


def query(sql, params=(), one=False):
    """Execute a SELECT query."""
    db = get_db()
    cur = db.execute(sql, params)
    rows = cur.fetchall()
    return (dict(rows[0]) if rows else None) if one else [dict(r) for r in rows]


def execute(sql, params=()):
    """Execute INSERT/UPDATE/DELETE, returns lastrowid."""
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    return cur.lastrowid


def row_to_dict(row):
    if row is None:
        return None
    return dict(row)
