"""
APEX FX — Users API
GET/PUT /api/users/profile
GET/PUT /api/users/preferences
GET     /api/users/stats
DELETE  /api/users/account
"""
from flask import Blueprint, request, jsonify, g
from database import query, execute
from middleware.auth import require_auth
from utils.validators import validate_email
from utils.helpers import now_iso, audit

users_bp = Blueprint("users", __name__)


# ── GET /api/users/profile ───────────────────────────────────
@users_bp.route("/profile", methods=["GET"])
@require_auth
def get_profile():
    user = query("""
        SELECT id, name, email, role, lang, avatar, bio, created_at, last_login
        FROM users WHERE id = ?
    """, (g.user_id,), one=True)
    return jsonify({"user": user})


# ── PUT /api/users/profile ───────────────────────────────────
@users_bp.route("/profile", methods=["PUT"])
@require_auth
def update_profile():
    data = request.get_json(silent=True) or {}
    allowed = {}

    if "name" in data:
        name = data["name"].strip()
        if len(name) < 2:
            return jsonify({"error": "Name must be at least 2 characters"}), 422
        allowed["name"] = name

    if "email" in data:
        email = data["email"].strip().lower()
        if not validate_email(email):
            return jsonify({"error": "Invalid email"}), 422
        existing = query("SELECT id FROM users WHERE email=? AND id!=?", (email, g.user_id), one=True)
        if existing:
            return jsonify({"error": "Email already in use"}), 409
        allowed["email"] = email

    if "bio" in data:
        allowed["bio"] = data["bio"][:500] if data["bio"] else None
    if "lang" in data and data["lang"] in ("ar", "en"):
        allowed["lang"] = data["lang"]

    if not allowed:
        return jsonify({"error": "No valid fields to update"}), 400

    set_clause = ", ".join(f"{k}=?" for k in allowed)
    values = list(allowed.values()) + [now_iso(), g.user_id]
    execute(f"UPDATE users SET {set_clause}, updated_at=? WHERE id=?", values)

    audit(g.user_id, "update_profile", "user", g.user_id, request.remote_addr)
    user = query("SELECT id, name, email, role, lang, avatar, bio FROM users WHERE id=?", (g.user_id,), one=True)
    return jsonify({"message": "Profile updated", "user": user})


# ── GET /api/users/preferences ───────────────────────────────
@users_bp.route("/preferences", methods=["GET"])
@require_auth
def get_preferences():
    prefs = query("SELECT * FROM user_preferences WHERE user_id=?", (g.user_id,), one=True)
    return jsonify({"preferences": prefs})


# ── PUT /api/users/preferences ───────────────────────────────
@users_bp.route("/preferences", methods=["PUT"])
@require_auth
def update_preferences():
    data = request.get_json(silent=True) or {}
    allowed = {}

    if "lang" in data and data["lang"] in ("ar", "en"):
        allowed["lang"] = data["lang"]
    if "default_lot_size" in data:
        ls = float(data["default_lot_size"])
        if 0.01 <= ls <= 100:
            allowed["default_lot_size"] = ls
    if "default_pair" in data:
        allowed["default_pair"] = str(data["default_pair"])[:10]
    if "notifications" in data:
        allowed["notifications"] = 1 if data["notifications"] else 0
    if "email_alerts" in data:
        allowed["email_alerts"] = 1 if data["email_alerts"] else 0
    if "show_welcome" in data:
        allowed["show_welcome"] = 1 if data["show_welcome"] else 0
    if "theme" in data and data["theme"] in ("dark", "light"):
        allowed["theme"] = data["theme"]

    if not allowed:
        return jsonify({"error": "No valid fields"}), 400

    set_clause = ", ".join(f"{k}=?" for k in allowed)
    values = list(allowed.values()) + [now_iso(), g.user_id]
    execute(f"UPDATE user_preferences SET {set_clause}, updated_at=? WHERE user_id=?", values)

    prefs = query("SELECT * FROM user_preferences WHERE user_id=?", (g.user_id,), one=True)
    return jsonify({"message": "Preferences updated", "preferences": prefs})


# ── GET /api/users/stats ─────────────────────────────────────
@users_bp.route("/stats", methods=["GET"])
@require_auth
def get_stats():
    uid = g.user_id

    fav_count   = query("SELECT COUNT(*) as n FROM favorites WHERE user_id=?", (uid,), one=True)["n"]
    alert_total = query("SELECT COUNT(*) as n FROM alerts WHERE user_id=?", (uid,), one=True)["n"]
    alert_active = query("SELECT COUNT(*) as n FROM alerts WHERE user_id=? AND is_triggered=0", (uid,), one=True)["n"]
    review_count = query("SELECT COUNT(*) as n FROM reviews WHERE user_id=?", (uid,), one=True)["n"]

    portfolio   = query("SELECT balance FROM portfolios WHERE user_id=?", (uid,), one=True)
    trade_count = query("SELECT COUNT(*) as n FROM trades WHERE user_id=?", (uid,), one=True)["n"]
    open_trades = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='open'", (uid,), one=True)["n"]
    wins        = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='closed' AND profit_loss>0", (uid,), one=True)["n"]
    losses      = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='closed' AND profit_loss<=0", (uid,), one=True)["n"]
    total_pl    = query("SELECT COALESCE(SUM(profit_loss),0) as s FROM trades WHERE user_id=? AND status='closed'", (uid,), one=True)["s"]

    return jsonify({
        "favorites": fav_count,
        "alerts": {"total": alert_total, "active": alert_active},
        "reviews": review_count,
        "portfolio": {
            "balance": portfolio["balance"] if portfolio else 100000,
            "total_trades": trade_count,
            "open_trades": open_trades,
            "closed_wins": wins,
            "closed_losses": losses,
            "total_pl": round(total_pl, 2),
            "win_rate": round(wins / (wins + losses) * 100, 1) if (wins + losses) > 0 else 0,
        }
    })


# ── DELETE /api/users/account ─────────────────────────────────
@users_bp.route("/account", methods=["DELETE"])
@require_auth
def delete_account():
    data = request.get_json(silent=True) or {}
    if not data.get("confirm"):
        return jsonify({"error": "Send {\"confirm\": true} to delete account"}), 400

    execute("UPDATE users SET is_active=0, email=?, updated_at=? WHERE id=?",
            (f"deleted_{g.user_id}@deleted.com", now_iso(), g.user_id))
    audit(g.user_id, "account_deleted", "user", g.user_id, request.remote_addr)
    return jsonify({"message": "Account deleted"})
