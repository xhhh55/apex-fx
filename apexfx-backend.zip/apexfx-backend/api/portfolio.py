"""
APEX FX — Virtual Portfolio API
GET    /api/portfolio             → summary
GET    /api/portfolio/trades      → open trades
POST   /api/portfolio/trades      → open trade
DELETE /api/portfolio/trades/:id  → close trade
GET    /api/portfolio/history     → closed trades
GET    /api/portfolio/stats       → performance stats
POST   /api/portfolio/reset       → reset to $100K
"""
from flask import Blueprint, request, jsonify, g, current_app
from database import query, execute
from middleware.auth import require_auth
from utils.helpers import now_iso, audit

portfolio_bp = Blueprint("portfolio", __name__)

PIP_VALUES = {
    "EUR/USD":10,"GBP/USD":10,"AUD/USD":10,"NZD/USD":10,
    "USD/JPY":6.67,"USD/CAD":7.35,"USD/CHF":11.32,
    "EUR/GBP":12.65,"EUR/JPY":7.14,"XAU/USD":1.0,
}
VALID_PAIRS = list(PIP_VALUES.keys())


def get_or_create_portfolio(user_id):
    p = query("SELECT * FROM portfolios WHERE user_id=?", (user_id,), one=True)
    if not p:
        now = now_iso()
        balance = current_app.config["PORTFOLIO_STARTING_BALANCE"]
        execute("INSERT INTO portfolios (user_id, balance, equity, created_at, updated_at) VALUES (?,?,?,?,?)",
                (user_id, balance, balance, now, now))
        p = query("SELECT * FROM portfolios WHERE user_id=?", (user_id,), one=True)
    return p


# ── GET /api/portfolio ───────────────────────────────────────
@portfolio_bp.route("", methods=["GET"])
@require_auth
def get_portfolio():
    p = get_or_create_portfolio(g.user_id)
    open_trades = query("SELECT * FROM trades WHERE user_id=? AND status='open' ORDER BY opened_at DESC", (g.user_id,))
    return jsonify({
        "portfolio": dict(p),
        "open_trades": open_trades,
        "open_count": len(open_trades),
    })


# ── GET /api/portfolio/trades ────────────────────────────────
@portfolio_bp.route("/trades", methods=["GET"])
@require_auth
def get_trades():
    trades = query("SELECT * FROM trades WHERE user_id=? AND status='open' ORDER BY opened_at DESC", (g.user_id,))
    return jsonify({"trades": trades, "count": len(trades)})


# ── POST /api/portfolio/trades ───────────────────────────────
@portfolio_bp.route("/trades", methods=["POST"])
@require_auth
def open_trade():
    data = request.get_json(silent=True) or {}
    pair        = (data.get("pair") or "").upper()
    direction   = (data.get("direction") or data.get("dir") or "").lower()
    lots        = data.get("lots") or data.get("lot_size")
    entry_price = data.get("entry_price") or data.get("price")
    stop_loss   = data.get("stop_loss")
    take_profit = data.get("take_profit")

    # Validate
    if pair not in VALID_PAIRS:
        return jsonify({"error": f"Invalid pair. Choose from: {VALID_PAIRS}"}), 422
    if direction not in ("buy","sell"):
        return jsonify({"error": "direction must be 'buy' or 'sell'"}), 422

    try:
        lots = float(lots or 0.1)
        if not (current_app.config["PORTFOLIO_MIN_LOTS"] <= lots <= current_app.config["PORTFOLIO_MAX_LOTS"]):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({"error": f"lots must be between {current_app.config['PORTFOLIO_MIN_LOTS']} and {current_app.config['PORTFOLIO_MAX_LOTS']}"}), 422

    try:
        entry_price = float(entry_price) if entry_price else None
    except (TypeError, ValueError):
        return jsonify({"error": "entry_price must be a number"}), 422

    if not entry_price:
        return jsonify({"error": "entry_price required"}), 422

    # Check open trade limit
    open_count = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='open'", (g.user_id,), one=True)["n"]
    max_open = current_app.config.get("PORTFOLIO_MAX_OPEN_TRADES", 20)
    if open_count >= max_open:
        return jsonify({"error": f"Maximum {max_open} open trades allowed"}), 429

    # Calculate margin (simplified: 0.2% of notional)
    pip_val = PIP_VALUES.get(pair, 10.0)
    notional = entry_price * lots * 100_000
    margin = round(notional * 0.002, 2)

    # Check balance
    p = get_or_create_portfolio(g.user_id)
    if p["balance"] < margin:
        return jsonify({"error": f"Insufficient balance. Required margin: ${margin:.2f}"}), 400

    now = now_iso()
    sl = float(stop_loss) if stop_loss else None
    tp = float(take_profit) if take_profit else None

    rid = execute("""
        INSERT INTO trades (user_id, pair, direction, lots, entry_price, stop_loss, take_profit,
                            pip_value, margin, status, opened_at)
        VALUES (?,?,?,?,?,?,?,?,?,'open',?)
    """, (g.user_id, pair, direction, lots, entry_price, sl, tp, pip_val, margin, now))

    # Deduct margin from balance
    execute("UPDATE portfolios SET balance=balance-?, updated_at=? WHERE user_id=?",
            (margin, now, g.user_id))

    trade = query("SELECT * FROM trades WHERE id=?", (rid,), one=True)
    audit(g.user_id, "open_trade", "trade", str(rid), request.remote_addr)
    return jsonify({"message": "Trade opened", "trade": trade}), 201


# ── DELETE /api/portfolio/trades/:id ────────────────────────
@portfolio_bp.route("/trades/<int:trade_id>", methods=["DELETE"])
@require_auth
def close_trade(trade_id):
    data = request.get_json(silent=True) or {}
    exit_price = data.get("exit_price") or data.get("price")

    trade = query("SELECT * FROM trades WHERE id=? AND user_id=? AND status='open'", (trade_id, g.user_id), one=True)
    if not trade:
        return jsonify({"error": "Open trade not found"}), 404

    try:
        exit_price = float(exit_price) if exit_price else None
    except (TypeError, ValueError):
        return jsonify({"error": "exit_price must be a number"}), 422

    if not exit_price:
        return jsonify({"error": "exit_price required"}), 422

    # Calculate P&L
    pair = trade["pair"]
    pips = (exit_price - trade["entry_price"]) * (100 if "JPY" in pair else 10000)
    if trade["direction"] == "sell":
        pips = -pips
    pl = round(pips * trade["pip_value"] * trade["lots"], 2)

    now = now_iso()
    execute("""
        UPDATE trades SET exit_price=?, profit_loss=?, status='closed', closed_at=?
        WHERE id=?
    """, (exit_price, pl, now, trade_id))

    # Return margin + P&L to balance
    balance_change = trade["margin"] + pl
    execute("UPDATE portfolios SET balance=balance+?, updated_at=? WHERE user_id=?",
            (balance_change, now, g.user_id))

    closed = query("SELECT * FROM trades WHERE id=?", (trade_id,), one=True)
    audit(g.user_id, "close_trade", "trade", str(trade_id), request.remote_addr)
    return jsonify({"message": "Trade closed", "trade": closed, "profit_loss": pl})


# ── GET /api/portfolio/history ───────────────────────────────
@portfolio_bp.route("/history", methods=["GET"])
@require_auth
def trade_history():
    limit  = min(int(request.args.get("limit", 50)), 200)
    offset = int(request.args.get("offset", 0))
    pair   = request.args.get("pair")

    if pair:
        rows = query("SELECT * FROM trades WHERE user_id=? AND status='closed' AND pair=? ORDER BY closed_at DESC LIMIT ? OFFSET ?",
                     (g.user_id, pair.upper(), limit, offset))
    else:
        rows = query("SELECT * FROM trades WHERE user_id=? AND status='closed' ORDER BY closed_at DESC LIMIT ? OFFSET ?",
                     (g.user_id, limit, offset))
    total = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='closed'", (g.user_id,), one=True)["n"]
    return jsonify({"history": rows, "total": total, "limit": limit, "offset": offset})


# ── GET /api/portfolio/stats ─────────────────────────────────
@portfolio_bp.route("/stats", methods=["GET"])
@require_auth
def portfolio_stats():
    p       = get_or_create_portfolio(g.user_id)
    closed  = query("SELECT * FROM trades WHERE user_id=? AND status='closed'", (g.user_id,))
    open_tr = query("SELECT * FROM trades WHERE user_id=? AND status='open'", (g.user_id,))

    wins    = [t for t in closed if (t["profit_loss"] or 0) > 0]
    losses  = [t for t in closed if (t["profit_loss"] or 0) <= 0]
    total_pl = sum((t["profit_loss"] or 0) for t in closed)
    best    = max((t["profit_loss"] or 0) for t in closed) if closed else 0
    worst   = min((t["profit_loss"] or 0) for t in closed) if closed else 0
    avg_win = (sum(t["profit_loss"] for t in wins) / len(wins)) if wins else 0
    avg_loss= (sum(t["profit_loss"] for t in losses) / len(losses)) if losses else 0

    # Pairs breakdown
    from collections import Counter
    pair_counts = Counter(t["pair"] for t in closed)

    return jsonify({
        "balance":      round(p["balance"], 2),
        "starting":     current_app.config["PORTFOLIO_STARTING_BALANCE"],
        "total_return": round(p["balance"] - current_app.config["PORTFOLIO_STARTING_BALANCE"], 2),
        "return_pct":   round((p["balance"] / current_app.config["PORTFOLIO_STARTING_BALANCE"] - 1) * 100, 2),
        "closed_trades": len(closed),
        "open_trades":  len(open_tr),
        "wins":         len(wins),
        "losses":       len(losses),
        "win_rate":     round(len(wins)/len(closed)*100, 1) if closed else 0,
        "total_pl":     round(total_pl, 2),
        "best_trade":   round(best, 2),
        "worst_trade":  round(worst, 2),
        "avg_win":      round(avg_win, 2),
        "avg_loss":     round(avg_loss, 2),
        "top_pairs":    dict(pair_counts.most_common(5)),
    })


# ── POST /api/portfolio/reset ────────────────────────────────
@portfolio_bp.route("/reset", methods=["POST"])
@require_auth
def reset_portfolio():
    balance = current_app.config["PORTFOLIO_STARTING_BALANCE"]
    now = now_iso()
    execute("UPDATE portfolios SET balance=?, equity=?, updated_at=? WHERE user_id=?",
            (balance, balance, now, g.user_id))
    execute("UPDATE trades SET status='closed', closed_at=?, profit_loss=0 WHERE user_id=? AND status='open'",
            (now, g.user_id))
    audit(g.user_id, "portfolio_reset", "portfolio", None, request.remote_addr)
    return jsonify({"message": "Portfolio reset to $100,000", "balance": balance})
