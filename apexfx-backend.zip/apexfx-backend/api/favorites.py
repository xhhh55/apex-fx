"""
APEX FX — Favorites API
GET    /api/favorites
POST   /api/favorites
DELETE /api/favorites/:broker_id
"""
from flask import Blueprint, request, jsonify, g
from database import query, execute, get_db
from middleware.auth import require_auth
from utils.helpers import now_iso, paginate, audit

favorites_bp = Blueprint("favorites", __name__)

@favorites_bp.route("", methods=["GET"])
@require_auth
def list_favorites():
    favs = query("SELECT * FROM favorites WHERE user_id=? ORDER BY added_at DESC", (g.user_id,))
    return jsonify({"favorites": favs, "count": len(favs)})

@favorites_bp.route("", methods=["POST"])
@require_auth
def add_favorite():
    data = request.get_json(silent=True) or {}
    broker_id   = data.get("broker_id")
    broker_name = data.get("broker_name", "")
    if not broker_id:
        return jsonify({"error": "broker_id required"}), 400

    existing = query("SELECT id FROM favorites WHERE user_id=? AND broker_id=?", (g.user_id, broker_id), one=True)
    if existing:
        return jsonify({"error": "Already in favorites"}), 409

    rid = execute("INSERT INTO favorites (user_id, broker_id, broker_name, added_at) VALUES (?,?,?,?)",
                  (g.user_id, broker_id, broker_name, now_iso()))
    fav = query("SELECT * FROM favorites WHERE id=?", (rid,), one=True)
    return jsonify({"message": "Added to favorites", "favorite": fav}), 201

@favorites_bp.route("/<int:broker_id>", methods=["DELETE"])
@require_auth
def remove_favorite(broker_id):
    existing = query("SELECT id FROM favorites WHERE user_id=? AND broker_id=?", (g.user_id, broker_id), one=True)
    if not existing:
        return jsonify({"error": "Not in favorites"}), 404
    execute("DELETE FROM favorites WHERE user_id=? AND broker_id=?", (g.user_id, broker_id))
    return jsonify({"message": "Removed from favorites"})

@favorites_bp.route("/export", methods=["GET"])
@require_auth
def export_favorites():
    favs = query("SELECT * FROM favorites WHERE user_id=? ORDER BY added_at DESC", (g.user_id,))
    return jsonify({"favorites": favs, "count": len(favs), "format": "json"})
