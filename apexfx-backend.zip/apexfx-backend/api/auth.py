"""
APEX FX — Auth API
POST /api/auth/register
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/refresh
GET  /api/auth/me
PUT  /api/auth/password
"""
import hashlib
import secrets
import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, g, current_app
from database import query, execute, get_db
from middleware.auth import require_auth, generate_tokens, hash_token
from utils.validators import validate_email, validate_password
from utils.helpers import now_iso, audit

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)


def hash_password(password: str, salt: str) -> str:
    """PBKDF2 password hashing (bcrypt not installed, this is secure enough)."""
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        310_000  # OWASP recommended iterations
    ).hex()


def verify_password(password: str, salt: str, stored_hash: str) -> bool:
    return secrets.compare_digest(hash_password(password, salt), stored_hash)


# ── POST /api/auth/register ──────────────────────────────────
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    name     = (data.get("name") or "").strip()
    email    = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    lang     = data.get("lang", "ar")

    # Validation
    errors = {}
    if not name or len(name) < 2:
        errors["name"] = "Name must be at least 2 characters"
    if not validate_email(email):
        errors["email"] = "Invalid email address"
    pw_err = validate_password(password)
    if pw_err:
        errors["password"] = pw_err
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 422

    # Check duplicate
    existing = query("SELECT id FROM users WHERE email = ?", (email,), one=True)
    if existing:
        return jsonify({"error": "Email already registered"}), 409

    # Create user
    uid  = "u_" + secrets.token_hex(12)
    salt = secrets.token_hex(16)
    pw_hash = hash_password(password, salt)
    stored  = f"{salt}:{pw_hash}"  # Store salt + hash together
    now  = now_iso()

    execute("""
        INSERT INTO users (id, name, email, password, role, lang, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'user', ?, ?, ?)
    """, (uid, name, email, stored, lang, now, now))

    execute("""
        INSERT INTO user_preferences (user_id, lang, updated_at)
        VALUES (?, ?, ?)
    """, (uid, lang, now))

    execute("""
        INSERT INTO portfolios (user_id, balance, equity, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
    """, (uid, current_app.config["PORTFOLIO_STARTING_BALANCE"],
          current_app.config["PORTFOLIO_STARTING_BALANCE"], now, now))

    # Generate tokens
    tokens = generate_tokens(uid, current_app.config)
    audit(uid, "register", "user", uid, request.remote_addr)

    user = query("SELECT id, name, email, role, lang, created_at FROM users WHERE id=?", (uid,), one=True)
    logger.info(f"New user registered: {email}")

    return jsonify({
        "message": "Registration successful",
        "user": user,
        **tokens,
    }), 201


# ── POST /api/auth/login ─────────────────────────────────────
@auth_bp.route("/login", methods=["POST"])
def login():
    data  = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or not password:
        return jsonify({"error": "Email and password required"}), 400

    user = query(
        "SELECT id, name, email, password, role, lang, is_active, is_banned FROM users WHERE email = ?",
        (email,), one=True
    )

    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    if user["is_banned"]:
        return jsonify({"error": "Account suspended. Contact support."}), 403

    if not user["is_active"]:
        return jsonify({"error": "Account inactive"}), 403

    # Verify password
    stored = user["password"]
    if ":" in stored:
        salt, pw_hash = stored.split(":", 1)
        if not verify_password(password, salt, pw_hash):
            return jsonify({"error": "Invalid credentials"}), 401
    else:
        # Legacy SHA256 (admin seed) — migrate on login
        legacy = hashlib.sha256((password + user["id"]).encode()).hexdigest()
        if not secrets.compare_digest(stored, legacy):
            return jsonify({"error": "Invalid credentials"}), 401
        # Migrate to PBKDF2
        salt = secrets.token_hex(16)
        new_hash = hash_password(password, salt)
        execute("UPDATE users SET password=? WHERE id=?", (f"{salt}:{new_hash}", user["id"]))

    # Update last login
    execute("UPDATE users SET last_login=? WHERE id=?", (now_iso(), user["id"]))

    tokens = generate_tokens(user["id"], current_app.config)
    audit(user["id"], "login", "user", user["id"], request.remote_addr)

    # Load preferences
    prefs = query("SELECT * FROM user_preferences WHERE user_id=?", (user["id"],), one=True)

    return jsonify({
        "message": "Login successful",
        "user": {k: user[k] for k in ("id","name","email","role","lang")},
        "preferences": prefs,
        **tokens,
    })


# ── POST /api/auth/logout ─────────────────────────────────────
@auth_bp.route("/logout", methods=["POST"])
@require_auth
def logout():
    auth_header = request.headers.get("Authorization", "")
    token = auth_header[7:] if auth_header.startswith("Bearer ") else ""
    if token:
        token_hash = hash_token(token)
        execute(
            "INSERT OR IGNORE INTO blacklisted_tokens (token_hash, revoked_at) VALUES (?,?)",
            (token_hash, now_iso())
        )
    audit(g.user_id, "logout", None, None, request.remote_addr)
    return jsonify({"message": "Logged out successfully"})


# ── POST /api/auth/refresh ────────────────────────────────────
@auth_bp.route("/refresh", methods=["POST"])
def refresh():
    import jwt as pyjwt
    data = request.get_json(silent=True) or {}
    refresh_token = data.get("refresh_token") or ""
    if not refresh_token:
        return jsonify({"error": "Refresh token required"}), 400

    try:
        payload = pyjwt.decode(
            refresh_token,
            current_app.config["JWT_SECRET"],
            algorithms=[current_app.config["JWT_ALGORITHM"]],
        )
    except pyjwt.ExpiredSignatureError:
        return jsonify({"error": "Refresh token expired"}), 401
    except pyjwt.InvalidTokenError:
        return jsonify({"error": "Invalid refresh token"}), 401

    if payload.get("type") != "refresh":
        return jsonify({"error": "Invalid token type"}), 401

    user_id = payload.get("sub")
    user = query("SELECT id FROM users WHERE id=? AND is_active=1 AND is_banned=0", (user_id,), one=True)
    if not user:
        return jsonify({"error": "User not found"}), 401

    tokens = generate_tokens(user_id, current_app.config)
    return jsonify({"message": "Token refreshed", **tokens})


# ── GET /api/auth/me ─────────────────────────────────────────
@auth_bp.route("/me", methods=["GET"])
@require_auth
def me():
    user = query("""
        SELECT u.id, u.name, u.email, u.role, u.lang, u.avatar, u.bio,
               u.created_at, u.last_login,
               p.lang as pref_lang, p.default_lot_size, p.default_pair, p.notifications
        FROM users u
        LEFT JOIN user_preferences p ON p.user_id = u.id
        WHERE u.id = ?
    """, (g.user_id,), one=True)

    # Stats
    fav_count  = query("SELECT COUNT(*) as n FROM favorites  WHERE user_id=?", (g.user_id,), one=True)["n"]
    alert_count = query("SELECT COUNT(*) as n FROM alerts WHERE user_id=? AND is_triggered=0", (g.user_id,), one=True)["n"]
    trade_count = query("SELECT COUNT(*) as n FROM trades WHERE user_id=? AND status='open'", (g.user_id,), one=True)["n"]
    portfolio   = query("SELECT balance, equity FROM portfolios WHERE user_id=?", (g.user_id,), one=True)

    return jsonify({
        "user": user,
        "stats": {
            "favorites": fav_count,
            "active_alerts": alert_count,
            "open_trades": trade_count,
            "portfolio_balance": portfolio["balance"] if portfolio else 100000,
        }
    })


# ── PUT /api/auth/password ────────────────────────────────────
@auth_bp.route("/password", methods=["PUT"])
@require_auth
def change_password():
    data = request.get_json(silent=True) or {}
    current_pw  = data.get("current_password") or ""
    new_pw      = data.get("new_password") or ""

    pw_err = validate_password(new_pw)
    if pw_err:
        return jsonify({"error": pw_err}), 422

    user = query("SELECT password FROM users WHERE id=?", (g.user_id,), one=True)
    stored = user["password"]
    salt, pw_hash = stored.split(":", 1)
    if not verify_password(current_pw, salt, pw_hash):
        return jsonify({"error": "Current password is incorrect"}), 401

    new_salt = secrets.token_hex(16)
    new_hash = hash_password(new_pw, new_salt)
    execute("UPDATE users SET password=?, updated_at=? WHERE id=?",
            (f"{new_salt}:{new_hash}", now_iso(), g.user_id))

    audit(g.user_id, "password_change", "user", g.user_id, request.remote_addr)
    return jsonify({"message": "Password changed successfully"})
