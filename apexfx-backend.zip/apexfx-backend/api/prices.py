"""
APEX FX — Live Prices API
GET /api/prices           → all pairs
GET /api/prices/:pair     → single pair
GET /api/prices/history   → 24h history
"""
import time
import threading
import logging
import urllib.request
import json
from flask import Blueprint, request, jsonify, current_app
from database import query, execute
from utils.helpers import now_iso

logger = logging.getLogger(__name__)
prices_bp = Blueprint("prices", __name__)

# ── In-memory cache ──────────────────────────────────────────
_cache_lock = threading.Lock()
_price_cache = {
    "data": [],
    "last_updated": 0,
    "source": "init",
}

# Base prices (fallback)
BASE_PRICES = [
    {"pair":"EUR/USD","price":1.08921,"pct":0.11,"bid":1.08919,"ask":1.08923,"vol":"$892B","pip_val":10,"spread":0.4,"desc":"Euro / US Dollar"},
    {"pair":"GBP/USD","price":1.26543,"pct":-0.18,"bid":1.26541,"ask":1.26546,"vol":"$422B","pip_val":10,"spread":0.7,"desc":"British Pound / Dollar"},
    {"pair":"USD/JPY","price":149.821,"pct":0.30,"bid":149.819,"ask":149.824,"vol":"$572B","pip_val":6.67,"spread":0.5,"desc":"Dollar / Japanese Yen"},
    {"pair":"AUD/USD","price":0.65421,"pct":-0.12,"bid":0.65420,"ask":0.65423,"vol":"$208B","pip_val":10,"spread":0.6,"desc":"Australian Dollar / Dollar"},
    {"pair":"USD/CAD","price":1.36213,"pct":0.11,"bid":1.36211,"ask":1.36215,"vol":"$182B","pip_val":7.35,"spread":0.8,"desc":"Dollar / Canadian Dollar"},
    {"pair":"USD/CHF","price":0.88341,"pct":-0.07,"bid":0.88339,"ask":0.88343,"vol":"$164B","pip_val":11.32,"spread":0.8,"desc":"Dollar / Swiss Franc"},
    {"pair":"NZD/USD","price":0.60891,"pct":0.07,"bid":0.60890,"ask":0.60892,"vol":"$114B","pip_val":10,"spread":1.0,"desc":"New Zealand Dollar / Dollar"},
    {"pair":"EUR/GBP","price":0.86081,"pct":0.02,"bid":0.86079,"ask":0.86083,"vol":"$96B","pip_val":12.65,"spread":0.9,"desc":"Euro / British Pound"},
    {"pair":"XAU/USD","price":2041.55,"pct":0.45,"bid":2041.30,"ask":2041.80,"vol":"$220B","pip_val":1.0,"spread":25,"desc":"Gold / US Dollar"},
    {"pair":"EUR/JPY","price":163.12,"pct":0.38,"bid":163.10,"ask":163.14,"vol":"$88B","pip_val":7.14,"spread":0.7,"desc":"Euro / Japanese Yen"},
]


def fetch_from_ecb() -> list | None:
    """Fetch real rates from Frankfurter (ECB data)."""
    try:
        url = "https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,AUD,CAD,CHF,NZD"
        req = urllib.request.Request(url, headers={"User-Agent":"ApexFX/2.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            d = json.loads(resp.read())
        rt = d.get("rates", {})
        updates = {
            "EUR/USD": round(1 / rt["EUR"], 5) if rt.get("EUR") else None,
            "GBP/USD": round(1 / rt["GBP"], 5) if rt.get("GBP") else None,
            "USD/JPY": round(rt.get("JPY", 0), 3),
            "AUD/USD": round(1 / rt["AUD"], 5) if rt.get("AUD") else None,
            "USD/CAD": round(rt.get("CAD", 0), 5),
            "USD/CHF": round(rt.get("CHF", 0), 5),
            "NZD/USD": round(1 / rt["NZD"], 5) if rt.get("NZD") else None,
            "EUR/GBP": round(rt.get("GBP",0)/rt.get("EUR",1), 5) if rt.get("EUR") and rt.get("GBP") else None,
            "EUR/JPY": round(rt.get("JPY",0)/rt.get("EUR",1), 3) if rt.get("EUR") else None,
        }
        return updates
    except Exception as e:
        logger.warning(f"ECB fetch failed: {e}")
        return None


def refresh_prices():
    """Refresh cache — called by scheduler and on first request."""
    global _price_cache
    ecb_data = fetch_from_ecb()
    now = time.time()

    with _cache_lock:
        current = {p["pair"]: p for p in (_price_cache["data"] or BASE_PRICES)}
        updated = []
        for base in BASE_PRICES:
            pair = base["pair"]
            cur  = current.get(pair, base)
            new_price = (ecb_data or {}).get(pair) if ecb_data else None

            if new_price and new_price > 0:
                old_price = cur["price"]
                pct = round((new_price - old_price) / old_price * 100, 2)
                spread_pts = base["spread"] * (0.01 if pair in ("XAU/USD",) else 0.00001)
                updated.append({**cur,
                    "price": new_price,
                    "pct": pct,
                    "bid": round(new_price - spread_pts, 5),
                    "ask": round(new_price + spread_pts, 5),
                    "source": "ecb",
                    "updated_at": now_iso(),
                })
            else:
                # Simulate small movement
                import random
                delta = (random.random() - 0.488) * 0.00012 * cur["price"]
                new_p = round(cur["price"] + delta, 5 if cur["price"] < 10 else (3 if cur["price"] < 100 else 2))
                spread_pts = base["spread"] * 0.00001
                updated.append({**cur,
                    "price": new_p,
                    "pct": round(cur["pct"] + (random.random()-0.5)*0.01, 2),
                    "bid": round(new_p - spread_pts, 5),
                    "ask": round(new_p + spread_pts, 5),
                    "source": "simulated",
                    "updated_at": now_iso(),
                })

        _price_cache = {
            "data": updated,
            "last_updated": now,
            "source": "ecb" if ecb_data else "simulated",
        }

    # Save snapshot to DB history
    try:
        from flask import current_app
        with current_app.app_context():
            for p in updated:
                execute("""
                    INSERT INTO price_history (pair, price, bid, ask, pct_change, source, recorded_at)
                    VALUES (?,?,?,?,?,?,?)
                """, (p["pair"], p["price"], p.get("bid"), p.get("ask"), p.get("pct"), p.get("source","sim"), now_iso()))
    except Exception as e:
        pass  # Non-critical


def get_cached_prices() -> list:
    """Return cached prices, refresh if stale."""
    ttl = 30
    with _cache_lock:
        age = time.time() - _price_cache["last_updated"]
        if age > ttl or not _price_cache["data"]:
            needs_refresh = True
        else:
            needs_refresh = False

    if needs_refresh:
        refresh_prices()

    with _cache_lock:
        return _price_cache["data"], _price_cache["source"], _price_cache["last_updated"]


# ── GET /api/prices ──────────────────────────────────────────
@prices_bp.route("", methods=["GET"])
def get_prices():
    data, source, ts = get_cached_prices()
    return jsonify({
        "prices": data,
        "count":  len(data),
        "source": source,
        "last_updated": now_iso(),
        "cache_age_sec": round(time.time() - ts, 1),
    })


# ── GET /api/prices/:pair ────────────────────────────────────
@prices_bp.route("/<path:pair>", methods=["GET"])
def get_price(pair):
    if pair == "history":
        return get_history()
    data, source, ts = get_cached_prices()
    pair = pair.upper().replace("-", "/")
    p = next((x for x in data if x["pair"] == pair), None)
    if not p:
        return jsonify({"error": f"Pair '{pair}' not found"}), 404
    return jsonify({"price": p, "source": source})


# ── GET /api/prices/history ──────────────────────────────────
def get_history():
    pair  = request.args.get("pair", "EUR/USD").upper()
    hours = min(int(request.args.get("hours", 24)), 168)
    limit = hours * 12  # 5-min intervals

    rows = query("""
        SELECT pair, price, bid, ask, pct_change, source, recorded_at
        FROM price_history
        WHERE pair=?
        ORDER BY recorded_at DESC
        LIMIT ?
    """, (pair, limit))
    return jsonify({"pair": pair, "history": list(reversed(rows)), "count": len(rows)})
