"""
APEX FX — News API
GET /api/news
GET /api/news/:id
GET /api/news/calendar
"""
from flask import Blueprint, request, jsonify
news_bp = Blueprint("news", __name__)

NEWS_DATA = [
    {"id":1,"title_ar":"الفيدرالي يُلمح إلى تأجيل خفض الفائدة","title_en":"Fed Signals Rate Cut Delay","source":"Reuters","time_min":12,"sentiment":"bearish","pairs":["USD/JPY","EUR/USD"],"summary_ar":"جاء مؤشر CPI مرتفعاً فوق المستهدف 2% للشهر الثالث، مما يجعل خفض الفائدة غير مرجح قريباً.","summary_en":"CPI came in above the 2% target for the third month, making near-term rate cuts unlikely."},
    {"id":2,"title_ar":"اليورو يرتفع بعد بيانات توظيف قوية","title_en":"Euro Surges on Strong Employment Data","source":"Bloomberg","time_min":45,"sentiment":"bullish","pairs":["EUR/USD","EUR/GBP"],"summary_ar":"انخفض معدل بطالة منطقة اليورو إلى 6.4%، أدنى مستوى في 25 عاماً.","summary_en":"Eurozone unemployment dropped to 6.4%, the lowest in 25 years."},
    {"id":3,"title_ar":"الجنيه يتراجع مع مخاوف الركود البريطاني","title_en":"Sterling Falls on UK Recession Fears","source":"FT","time_min":2,"sentiment":"bearish","pairs":["GBP/USD","EUR/GBP"],"summary_ar":"تقلص الاقتصاد البريطاني 0.3% في الربع الأخير.","summary_en":"UK economy contracted 0.3% in Q4, confirming a technical recession."},
    {"id":4,"title_ar":"الذهب يسجل أعلى مستوياته منذ 6 أشهر","title_en":"Gold Hits 6-Month High","source":"CNBC","time_min":90,"sentiment":"bullish","pairs":["XAU/USD"],"summary_ar":"قفز الذهب فوق $2,060 مدفوعاً بالطلب على الملاذ الآمن.","summary_en":"Gold broke above $2,060 driven by safe-haven demand."},
    {"id":5,"title_ar":"Exness تسجل $5.1T حجم تداول في أبريل","title_en":"Exness Records $5.1T Volume in April","source":"Finance Magnates","time_min":180,"sentiment":"neutral","pairs":["EUR/USD"],"summary_ar":"رقم قياسي جديد لـ Exness بزيادة 34% عن الشهر السابق.","summary_en":"New record for Exness, a 34% jump from the previous month."},
]

CALENDAR_DATA = [
    {"time":"08:30","currency":"USD","flag":"🇺🇸","event_ar":"مؤشر CPI الأمريكي","event_en":"US CPI m/m","impact":"high","forecast":"0.3%","previous":"0.4%","actual":"0.3%"},
    {"time":"10:00","currency":"EUR","flag":"🇪🇺","event_ar":"قرار الفائدة الأوروبي","event_en":"ECB Rate Decision","impact":"high","forecast":"4.50%","previous":"4.50%","actual":None},
    {"time":"12:30","currency":"GBP","flag":"🇬🇧","event_ar":"بيانات التوظيف البريطاني","event_en":"UK Employment Change","impact":"medium","forecast":"48K","previous":"52K","actual":None},
    {"time":"14:00","currency":"USD","flag":"🇺🇸","event_ar":"مبيعات التجزئة","event_en":"Retail Sales m/m","impact":"medium","forecast":"0.4%","previous":"0.6%","actual":None},
    {"time":"15:30","currency":"CAD","flag":"🇨🇦","event_ar":"قرار الفائدة الكندي","event_en":"BOC Rate Decision","impact":"high","forecast":"5.00%","previous":"5.00%","actual":None},
    {"time":"20:00","currency":"USD","flag":"🇺🇸","event_ar":"محاضر الفيدرالي","event_en":"FOMC Minutes","impact":"high","forecast":"—","previous":"—","actual":None},
]

@news_bp.route("", methods=["GET"])
def get_news():
    sentiment = request.args.get("sentiment")
    pair = request.args.get("pair")
    data = list(NEWS_DATA)
    if sentiment and sentiment != "all":
        data = [n for n in data if n["sentiment"] == sentiment]
    if pair:
        data = [n for n in data if pair.upper() in n["pairs"]]
    return jsonify({"news": data, "count": len(data)})

@news_bp.route("/calendar", methods=["GET"])
def get_calendar():
    impact = request.args.get("impact")
    data = list(CALENDAR_DATA)
    if impact:
        data = [e for e in data if e["impact"] == impact]
    return jsonify({"events": data, "count": len(data)})

@news_bp.route("/<int:news_id>", methods=["GET"])
def get_news_item(news_id):
    item = next((n for n in NEWS_DATA if n["id"] == news_id), None)
    if not item:
        return jsonify({"error": "News item not found"}), 404
    return jsonify({"news": item})
