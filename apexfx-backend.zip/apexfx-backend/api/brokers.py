"""
APEX FX — Brokers API
GET /api/brokers
GET /api/brokers/:id
GET /api/brokers/search
"""
from flask import Blueprint, request, jsonify, g
from database import query
from middleware.auth import optional_auth

brokers_bp = Blueprint("brokers", __name__)

BROKERS_DATA = [
    {"id":1,"name":"IC Markets","logo":"ICM","rating":4.9,"tier":"GOLD","founded":2007,"country_ar":"أستراليا","country_en":"Australia","hq":"Sydney","type_ar":"ECN","type_en":"ECN","regulation":["ASIC","CySEC","FSA"],"min_deposit":200,"max_leverage":"1:500","spread":0.02,"commission":7.0,"instruments":3583,"forex_pairs":61,"exec_speed_ms":40,"clients":"200K+","monthly_volume":"$1.2T","countries":200,"platforms":["MT4","MT5","cTrader","TradingView"],"features_ar":["ECN حقيقي","سبريد 0.0","VPS مجاني","API متقدم"],"features_en":["True ECN","0.0 spread","Free VPS","Advanced API"],"score":{"safety":97,"cost":93,"platform":91,"support":88,"speed":96},"badge_ar":"#1 حجماً","badge_en":"#1 Volume","awards":["Best ECN 2024","Lowest Spreads"],"islamic_account":True,"negative_balance":True,"desc_ar":"أكبر وسيط فوركس عالمياً من حيث الحجم","desc_en":"World's #1 forex broker by trading volume"},
    {"id":2,"name":"Pepperstone","logo":"PPS","rating":4.8,"tier":"GOLD","founded":2010,"country_ar":"أستراليا","country_en":"Australia","hq":"Melbourne","type_ar":"ECN/STP","type_en":"ECN/STP","regulation":["ASIC","FCA","CySEC","BaFin","DFSA"],"min_deposit":0,"max_leverage":"1:500","spread":0.10,"commission":7.0,"instruments":1726,"forex_pairs":65,"exec_speed_ms":30,"clients":"400K+","monthly_volume":"$800B","countries":160,"platforms":["MT4","MT5","cTrader","TradingView"],"features_ar":["7 تراخيص","سرعة 30ms","Autochartist","بلا حد أدنى"],"features_en":["7 licenses","30ms speed","Autochartist","No min deposit"],"score":{"safety":98,"cost":89,"platform":95,"support":91,"speed":97},"badge_ar":"أفضل منصة","badge_en":"Best Platform","awards":["Best Broker 2024","Most Trusted"],"islamic_account":True,"negative_balance":True,"desc_ar":"7 تراخيص عالمية","desc_en":"7 global licenses, advanced platforms"},
    {"id":3,"name":"Exness","logo":"EXN","rating":4.7,"tier":"GOLD","founded":2008,"country_ar":"قبرص","country_en":"Cyprus","hq":"Limassol","type_ar":"ECN/STP","type_en":"ECN/STP","regulation":["FCA","CySEC","FSCA","CMA","FSA"],"min_deposit":1,"max_leverage":"1:2000","spread":0.10,"commission":0,"instruments":230,"forex_pairs":90,"exec_speed_ms":25,"clients":"836K+","monthly_volume":"$5.1T","countries":130,"platforms":["MT4","MT5","Exness Terminal"],"features_ar":["$5.1T شهرياً","سحب فوري","رافعة 1:2000","90+ زوج"],"features_en":["$5.1T monthly","Instant withdrawal","1:2000 leverage","90+ pairs"],"score":{"safety":88,"cost":95,"platform":87,"support":90,"speed":98},"badge_ar":"أعلى حجم","badge_en":"Highest Volume","awards":["Record Volume 2024","Best CFD"],"islamic_account":True,"negative_balance":True,"desc_ar":"$5.1 تريليون شهرياً — رقم قياسي","desc_en":"$5.1T monthly — verified world record"},
    {"id":4,"name":"XM Group","logo":"XMG","rating":4.6,"tier":"SILVER","founded":2009,"country_ar":"قبرص","country_en":"Cyprus","hq":"Limassol","type_ar":"صانع سوق","type_en":"Market Maker","regulation":["ASIC","CySEC","IFSC"],"min_deposit":5,"max_leverage":"1:1000","spread":0.60,"commission":0,"instruments":1380,"forex_pairs":55,"exec_speed_ms":100,"clients":"15M+","monthly_volume":"$300B","countries":196,"platforms":["MT4","MT5","XM App"],"features_ar":["15 مليون عميل","مكافآت $500","تحليل يومي","196 دولة"],"features_en":["15M clients","$500 bonus","Daily analysis","196 countries"],"score":{"safety":87,"cost":84,"platform":85,"support":93,"speed":75},"badge_ar":"15M عميل","badge_en":"15M Clients","awards":["Best Service 2024"],"islamic_account":True,"negative_balance":True,"desc_ar":"15 مليون عميل في 196 دولة","desc_en":"15M clients across 196 countries"},
    {"id":5,"name":"eToro","logo":"ETR","rating":4.5,"tier":"SILVER","founded":2007,"country_ar":"إسرائيل","country_en":"Israel","hq":"Tel Aviv","type_ar":"اجتماعي","type_en":"Social Trading","regulation":["FCA","CySEC","ASIC","SEC"],"min_deposit":50,"max_leverage":"1:30","spread":1.0,"commission":0,"instruments":3000,"forex_pairs":49,"exec_speed_ms":200,"clients":"35M+","monthly_volume":"$50B","countries":140,"platforms":["eToro","eToro App"],"features_ar":["35M مستخدم","CopyTrader","3000+ أصل"],"features_en":["35M users","CopyTrader","3000+ assets"],"score":{"safety":94,"cost":70,"platform":90,"support":85,"speed":65},"badge_ar":"#1 اجتماعي","badge_en":"#1 Social","awards":["Best Social 2024"],"islamic_account":True,"negative_balance":True,"desc_ar":"35 مليون مستخدم، انسخ أفضل المتداولين","desc_en":"35M users, copy top traders automatically"},
    {"id":6,"name":"FXCM","logo":"FXC","rating":4.3,"tier":"BRONZE","founded":1999,"country_ar":"الولايات المتحدة","country_en":"United States","hq":"New York","type_ar":"صانع سوق","type_en":"Market Maker","regulation":["FCA","ASIC","FSCA"],"min_deposit":50,"max_leverage":"1:400","spread":1.30,"commission":0,"instruments":300,"forex_pairs":40,"exec_speed_ms":150,"clients":"70K+","monthly_volume":"$130B","countries":120,"platforms":["Trading Station","MT4","NinjaTrader"],"features_ar":["25 عاماً خبرة","تداول آلي","API متقدم"],"features_en":["25 yrs experience","Algo trading","Advanced API"],"score":{"safety":91,"cost":76,"platform":88,"support":82,"speed":72},"badge_ar":"خبرة 25 عام","badge_en":"25 Yrs Exp","awards":["Best Research 2024"],"islamic_account":False,"negative_balance":False,"desc_ar":"من أقدم وسطاء العالم منذ 1999","desc_en":"One of the world's oldest brokers since 1999"},
]

BROKERS_MAP = {b["id"]: b for b in BROKERS_DATA}


@brokers_bp.route("", methods=["GET"])
def list_brokers():
    sort = request.args.get("sort", "rating")
    tier = request.args.get("tier")
    btype = request.args.get("type", "").lower()
    lang = request.args.get("lang", "en")

    data = list(BROKERS_DATA)
    if tier:
        data = [b for b in data if b["tier"].lower() == tier.lower()]
    if btype and btype != "all":
        data = [b for b in data if btype in b["type_en"].lower()]
    if sort == "rating":
        data.sort(key=lambda b: b["rating"], reverse=True)
    elif sort == "spread":
        data.sort(key=lambda b: b["spread"])
    elif sort == "deposit":
        data.sort(key=lambda b: b["min_deposit"])

    # Append review stats
    for b in data:
        rev = query("SELECT COUNT(*) as n, AVG(rating) as a FROM reviews WHERE broker_id=?", (b["id"],), one=True)
        b["review_count"] = rev["n"]
        b["review_avg"]   = round(rev["a"], 2) if rev["a"] else 0

    return jsonify({"brokers": data, "count": len(data)})


@brokers_bp.route("/search", methods=["GET"])
def search_brokers():
    q = (request.args.get("q") or "").lower()
    if not q:
        return jsonify({"brokers": [], "count": 0})
    results = [b for b in BROKERS_DATA if
               q in b["name"].lower() or
               any(q in r.lower() for r in b["regulation"]) or
               q in b["type_en"].lower()]
    return jsonify({"brokers": results, "count": len(results), "query": q})


@brokers_bp.route("/<int:broker_id>", methods=["GET"])
def get_broker(broker_id):
    b = BROKERS_MAP.get(broker_id)
    if not b:
        return jsonify({"error": "Broker not found"}), 404
    rev = query("SELECT COUNT(*) as n, AVG(rating) as a FROM reviews WHERE broker_id=? AND is_approved=1", (broker_id,), one=True)
    result = {**b, "review_count": rev["n"], "review_avg": round(rev["a"], 2) if rev["a"] else 0}
    return jsonify({"broker": result})
