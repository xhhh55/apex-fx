"""
APEX FX — Analytics API
GET /api/analytics/market
GET /api/analytics/rankings
"""
from flask import Blueprint, jsonify, request, g
from database import query
from middleware.auth import require_admin

analytics_bp = Blueprint("analytics", __name__)

@analytics_bp.route("/market", methods=["GET"])
def market_stats():
    return jsonify({
        "daily_volume":   "$7.5T",
        "top_pair":       "EUR/USD",
        "top_pair_share": "28%",
        "exness_monthly": "$5.1T",
        "xm_clients":     "15M+",
        "etoro_users":    "35M+",
        "fastest_exec":   "25ms",
        "stats": [
            {"label_ar":"أكثر الأزواج","label_en":"Most Traded Pair","val":"EUR/USD","sub_ar":"28% من الحجم","sub_en":"28% of global volume"},
            {"label_ar":"Exness أبريل 2024","label_en":"Exness Apr 2024","val":"$5.1T","sub_ar":"رقم قياسي موثق","sub_en":"Verified record"},
            {"label_ar":"XM Group","label_en":"XM Group","val":"15M+","sub_ar":"عميل حول العالم","sub_en":"Registered clients"},
            {"label_ar":"eToro","label_en":"eToro","val":"35M+","sub_ar":"مستخدم","sub_en":"Platform users"},
        ]
    })


@analytics_bp.route("/rankings", methods=["GET"])
def rankings():
    from api.brokers import BROKERS_DATA
    by_rating  = sorted(BROKERS_DATA, key=lambda b: b["rating"], reverse=True)
    by_spread  = sorted(BROKERS_DATA, key=lambda b: b["spread"])
    by_speed   = sorted(BROKERS_DATA, key=lambda b: b["exec_speed_ms"])
    by_safety  = sorted(BROKERS_DATA, key=lambda b: b["score"]["safety"], reverse=True)
    return jsonify({
        "by_rating":  [{"id":b["id"],"name":b["name"],"value":b["rating"]} for b in by_rating],
        "by_spread":  [{"id":b["id"],"name":b["name"],"value":b["spread"]} for b in by_spread],
        "by_speed":   [{"id":b["id"],"name":b["name"],"value":b["exec_speed_ms"]} for b in by_speed],
        "by_safety":  [{"id":b["id"],"name":b["name"],"value":b["score"]["safety"]} for b in by_safety],
    })


"""
APEX FX — Admin API
GET /api/admin/users
GET /api/admin/stats
PUT /api/admin/users/:id/ban
"""
admin_bp = Blueprint("admin", __name__)

@admin_bp.route("/stats", methods=["GET"])
@require_admin
def admin_stats():
    total_users    = query("SELECT COUNT(*) as n FROM users WHERE is_active=1", (), one=True)["n"]
    new_today      = query("SELECT COUNT(*) as n FROM users WHERE date(created_at)=date('now')", (), one=True)["n"]
    total_trades   = query("SELECT COUNT(*) as n FROM trades", (), one=True)["n"]
    open_trades    = query("SELECT COUNT(*) as n FROM trades WHERE status='open'", (), one=True)["n"]
    total_alerts   = query("SELECT COUNT(*) as n FROM alerts WHERE is_triggered=0", (), one=True)["n"]
    total_reviews  = query("SELECT COUNT(*) as n FROM reviews", (), one=True)["n"]
    total_favs     = query("SELECT COUNT(*) as n FROM favorites", (), one=True)["n"]
    price_records  = query("SELECT COUNT(*) as n FROM price_history", (), one=True)["n"]
    return jsonify({
        "users":     {"total": total_users, "new_today": new_today},
        "trades":    {"total": total_trades, "open": open_trades},
        "alerts":    {"active": total_alerts},
        "reviews":   {"total": total_reviews},
        "favorites": {"total": total_favs},
        "prices":    {"history_records": price_records},
    })


@admin_bp.route("/users", methods=["GET"])
@require_admin
def admin_users():
    limit  = min(int(request.args.get("limit", 50)), 200)
    offset = int(request.args.get("offset", 0))
    rows   = query("""
        SELECT id, name, email, role, lang, is_active, is_banned, created_at, last_login
        FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?
    """, (limit, offset))
    total  = query("SELECT COUNT(*) as n FROM users", (), one=True)["n"]
    return jsonify({"users": rows, "total": total, "limit": limit, "offset": offset})


@admin_bp.route("/users/<user_id>/ban", methods=["PUT"])
@require_admin
def ban_user(user_id):
    if user_id == g.user_id:
        return jsonify({"error": "Cannot ban yourself"}), 400
    data = request.get_json(silent=True) or {}
    banned = 1 if data.get("banned", True) else 0
    from database import execute
    from utils.helpers import now_iso
    execute("UPDATE users SET is_banned=?, updated_at=? WHERE id=?", (banned, now_iso(), user_id))
    action = "banned" if banned else "unbanned"
    return jsonify({"message": f"User {action} successfully"})
