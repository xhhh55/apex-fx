"""
APEX FX — Price Alerts API
GET    /api/alerts
POST   /api/alerts
PUT    /api/alerts/:id
DELETE /api/alerts/:id
POST   /api/alerts/check  (called by scheduler)
"""
from flask import Blueprint, request, jsonify, g, current_app
from database import query, execute
from middleware.auth import require_auth
from utils.helpers import now_iso, audit

alerts_bp = Blueprint("alerts", __name__)

VALID_PAIRS = ["EUR/USD","GBP/USD","USD/JPY","AUD/USD","USD/CAD","USD/CHF","NZD/USD","EUR/GBP","XAU/USD","EUR/JPY"]


@alerts_bp.route("", methods=["GET"])
@require_auth
def list_alerts():
    status = request.args.get("status", "all")  # all | active | triggered
    if status == "active":
        rows = query("SELECT * FROM alerts WHERE user_id=? AND is_triggered=0 ORDER BY created_at DESC", (g.user_id,))
    elif status == "triggered":
        rows = query("SELECT * FROM alerts WHERE user_id=? AND is_triggered=1 ORDER BY triggered_at DESC", (g.user_id,))
    else:
        rows = query("SELECT * FROM alerts WHERE user_id=? ORDER BY created_at DESC", (g.user_id,))
    return jsonify({"alerts": rows, "count": len(rows)})


@alerts_bp.route("", methods=["POST"])
@require_auth
def create_alert():
    data = request.get_json(silent=True) or {}
    pair         = data.get("pair", "").upper()
    target_price = data.get("target_price") or data.get("price")
    direction    = data.get("direction", "above")
    note         = data.get("note", "")

    if pair not in VALID_PAIRS:
        return jsonify({"error": f"Invalid pair. Valid: {VALID_PAIRS}"}), 422
    if target_price is None:
        return jsonify({"error": "target_price required"}), 422
    if direction not in ("above", "below"):
        return jsonify({"error": "direction must be 'above' or 'below'"}), 422

    try:
        target_price = float(target_price)
        if target_price <= 0:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({"error": "target_price must be a positive number"}), 422

    # Limit alerts per user
    count = query("SELECT COUNT(*) as n FROM alerts WHERE user_id=? AND is_triggered=0", (g.user_id,), one=True)["n"]
    max_alerts = current_app.config.get("MAX_ALERTS_PER_USER", 20)
    if count >= max_alerts:
        return jsonify({"error": f"Maximum {max_alerts} active alerts allowed"}), 429

    now = now_iso()
    rid = execute("""
        INSERT INTO alerts (user_id, pair, target_price, direction, note, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?)
    """, (g.user_id, pair, target_price, direction, note, now, now))

    alert = query("SELECT * FROM alerts WHERE id=?", (rid,), one=True)
    return jsonify({"message": "Alert created", "alert": alert}), 201


@alerts_bp.route("/<int:alert_id>", methods=["PUT"])
@require_auth
def update_alert(alert_id):
    alert = query("SELECT * FROM alerts WHERE id=? AND user_id=?", (alert_id, g.user_id), one=True)
    if not alert:
        return jsonify({"error": "Alert not found"}), 404

    data = request.get_json(silent=True) or {}
    allowed = {}
    if "target_price" in data:
        try:
            tp = float(data["target_price"])
            if tp > 0:
                allowed["target_price"] = tp
        except (TypeError, ValueError):
            pass
    if "direction" in data and data["direction"] in ("above","below"):
        allowed["direction"] = data["direction"]
    if "note" in data:
        allowed["note"] = data["note"]

    if allowed:
        set_clause = ", ".join(f"{k}=?" for k in allowed)
        execute(f"UPDATE alerts SET {set_clause}, updated_at=? WHERE id=?",
                list(allowed.values()) + [now_iso(), alert_id])

    updated = query("SELECT * FROM alerts WHERE id=?", (alert_id,), one=True)
    return jsonify({"message": "Alert updated", "alert": updated})


@alerts_bp.route("/<int:alert_id>", methods=["DELETE"])
@require_auth
def delete_alert(alert_id):
    alert = query("SELECT id FROM alerts WHERE id=? AND user_id=?", (alert_id, g.user_id), one=True)
    if not alert:
        return jsonify({"error": "Alert not found"}), 404
    execute("DELETE FROM alerts WHERE id=?", (alert_id,))
    return jsonify({"message": "Alert deleted"})


@alerts_bp.route("/check", methods=["POST"])
def check_alerts():
    """Called by scheduler every 30s with current prices."""
    data = request.get_json(silent=True) or {}
    prices = data.get("prices", {})  # {pair: price}
    if not prices:
        return jsonify({"checked": 0, "triggered": 0})

    active = query("SELECT * FROM alerts WHERE is_triggered=0")
    triggered_count = 0
    for alert in active:
        cur_price = prices.get(alert["pair"])
        if cur_price is None:
            continue
        should_trigger = (
            (alert["direction"] == "above" and cur_price >= alert["target_price"]) or
            (alert["direction"] == "below" and cur_price <= alert["target_price"])
        )
        if should_trigger:
            execute("""
                UPDATE alerts SET is_triggered=1, triggered_price=?, triggered_at=?, updated_at=?
                WHERE id=?
            """, (cur_price, now_iso(), now_iso(), alert["id"]))
            triggered_count += 1

    return jsonify({"checked": len(active), "triggered": triggered_count})
