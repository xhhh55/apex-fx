"""
APEX FX — Reviews API
GET    /api/reviews/:broker_id
POST   /api/reviews/:broker_id
PUT    /api/reviews/:id
DELETE /api/reviews/:id
POST   /api/reviews/:id/like
"""
from flask import Blueprint, request, jsonify, g
from database import query, execute
from middleware.auth import require_auth, optional_auth
from utils.helpers import now_iso

reviews_bp = Blueprint("reviews", __name__)


@reviews_bp.route("/<int:broker_id>", methods=["GET"])
def get_reviews(broker_id):
    limit  = min(int(request.args.get("limit", 20)), 100)
    offset = int(request.args.get("offset", 0))
    sort   = request.args.get("sort", "recent")  # recent | rating | likes

    order = {"recent":"created_at DESC","rating":"rating DESC","likes":"likes DESC"}.get(sort, "created_at DESC")
    rows  = query(f"""
        SELECT r.*, u.name as user_name, u.avatar as user_avatar
        FROM reviews r
        JOIN users u ON u.id = r.user_id
        WHERE r.broker_id=? AND r.is_approved=1
        ORDER BY {order}
        LIMIT ? OFFSET ?
    """, (broker_id, limit, offset))

    total = query("SELECT COUNT(*) as n FROM reviews WHERE broker_id=? AND is_approved=1", (broker_id,), one=True)["n"]
    avg   = query("SELECT AVG(rating) as a FROM reviews WHERE broker_id=? AND is_approved=1", (broker_id,), one=True)["a"]

    dist  = {i: 0 for i in range(1,6)}
    for r in query("SELECT rating, COUNT(*) as n FROM reviews WHERE broker_id=? AND is_approved=1 GROUP BY rating", (broker_id,)):
        dist[r["rating"]] = r["n"]

    return jsonify({
        "reviews":   rows,
        "total":     total,
        "avg_rating": round(avg, 2) if avg else 0,
        "distribution": dist,
        "limit":     limit,
        "offset":    offset,
    })


@reviews_bp.route("/<int:broker_id>", methods=["POST"])
@require_auth
def submit_review(broker_id):
    data   = request.get_json(silent=True) or {}
    rating = data.get("rating")
    body   = (data.get("body") or data.get("text") or "").strip()
    title  = (data.get("title") or "").strip()[:120]
    lang   = data.get("lang", "ar")

    if not rating or not isinstance(rating, int) or not (1 <= rating <= 5):
        return jsonify({"error": "rating must be integer 1-5"}), 422
    if not body or len(body) < 10:
        return jsonify({"error": "Review body must be at least 10 characters"}), 422
    if len(body) > 1000:
        return jsonify({"error": "Review body max 1000 characters"}), 422

    existing = query("SELECT id FROM reviews WHERE user_id=? AND broker_id=?", (g.user_id, broker_id), one=True)
    if existing:
        return jsonify({"error": "You already reviewed this broker. Edit your existing review."}), 409

    now = now_iso()
    rid = execute("""
        INSERT INTO reviews (user_id, broker_id, rating, title, body, lang, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?)
    """, (g.user_id, broker_id, rating, title, body, lang, now, now))

    review = query("""
        SELECT r.*, u.name as user_name FROM reviews r
        JOIN users u ON u.id=r.user_id WHERE r.id=?
    """, (rid,), one=True)
    return jsonify({"message": "Review submitted", "review": review}), 201


@reviews_bp.route("/<int:review_id>/edit", methods=["PUT"])
@require_auth
def edit_review(review_id):
    review = query("SELECT * FROM reviews WHERE id=? AND user_id=?", (review_id, g.user_id), one=True)
    if not review:
        return jsonify({"error": "Review not found or not yours"}), 404

    data = request.get_json(silent=True) or {}
    allowed = {}
    if "rating" in data and isinstance(data["rating"], int) and 1 <= data["rating"] <= 5:
        allowed["rating"] = data["rating"]
    if "body" in data and len(data["body"].strip()) >= 10:
        allowed["body"] = data["body"].strip()[:1000]
    if "title" in data:
        allowed["title"] = data["title"][:120]

    if allowed:
        set_clause = ", ".join(f"{k}=?" for k in allowed)
        execute(f"UPDATE reviews SET {set_clause}, updated_at=? WHERE id=?",
                list(allowed.values()) + [now_iso(), review_id])

    updated = query("SELECT * FROM reviews WHERE id=?", (review_id,), one=True)
    return jsonify({"message": "Review updated", "review": updated})


@reviews_bp.route("/<int:review_id>", methods=["DELETE"])
@require_auth
def delete_review(review_id):
    review = query("SELECT id FROM reviews WHERE id=? AND user_id=?", (review_id, g.user_id), one=True)
    if not review:
        return jsonify({"error": "Review not found or not yours"}), 404
    execute("DELETE FROM reviews WHERE id=?", (review_id,))
    return jsonify({"message": "Review deleted"})


@reviews_bp.route("/<int:review_id>/like", methods=["POST"])
@require_auth
def like_review(review_id):
    existing = query("SELECT 1 FROM review_likes WHERE user_id=? AND review_id=?", (g.user_id, review_id), one=True)
    if existing:
        execute("DELETE FROM review_likes WHERE user_id=? AND review_id=?", (g.user_id, review_id))
        execute("UPDATE reviews SET likes=MAX(0,likes-1) WHERE id=?", (review_id,))
        return jsonify({"message": "Like removed"})
    else:
        execute("INSERT INTO review_likes (user_id, review_id) VALUES (?,?)", (g.user_id, review_id))
        execute("UPDATE reviews SET likes=likes+1 WHERE id=?", (review_id,))
        return jsonify({"message": "Review liked"})
