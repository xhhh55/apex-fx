"""
APEX FX — Helper Utilities
"""
import re
from datetime import datetime, timezone


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def paginate(items: list, page: int = 1, per_page: int = 20) -> dict:
    total = len(items)
    start = (page - 1) * per_page
    end   = start + per_page
    return {
        "items":    items[start:end],
        "total":    total,
        "page":     page,
        "per_page": per_page,
        "pages":    (total + per_page - 1) // per_page,
    }


def audit(user_id, action, entity, entity_id, ip=None, details=None):
    """Write to audit log (best-effort)."""
    try:
        from database import execute
        execute("""
            INSERT INTO audit_log (user_id, action, entity, entity_id, details, ip, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (user_id, action, entity, entity_id, details, ip, now_iso()))
    except Exception:
        pass
