"""
APEX FX — Background Scheduler
Runs in a daemon thread alongside Flask:
  - Refreshes prices every 30s from ECB
  - Checks price alerts every 30s
  - Cleans expired blacklisted tokens every hour
"""
import threading
import time
import logging
import urllib.request
import json

logger = logging.getLogger(__name__)
_scheduler_started = False


def start_scheduler(app):
    global _scheduler_started
    if _scheduler_started:
        return
    _scheduler_started = True

    def run():
        logger.info("⏰ Scheduler started")
        tick = 0
        while True:
            time.sleep(30)
            tick += 1
            try:
                with app.app_context():
                    # 1. Refresh prices
                    from api.prices import refresh_prices
                    refresh_prices()

                    # 2. Check alerts with current prices
                    from api.prices import get_cached_prices
                    prices_list, _, _ = get_cached_prices()
                    prices_dict = {p["pair"]: p["price"] for p in prices_list}

                    from database import query, execute
                    from utils.helpers import now_iso
                    active_alerts = query("SELECT * FROM alerts WHERE is_triggered=0")
                    triggered = 0
                    for alert in active_alerts:
                        cur = prices_dict.get(alert["pair"])
                        if cur is None:
                            continue
                        should = (
                            (alert["direction"] == "above" and cur >= alert["target_price"]) or
                            (alert["direction"] == "below" and cur <= alert["target_price"])
                        )
                        if should:
                            execute("""
                                UPDATE alerts
                                SET is_triggered=1, triggered_price=?, triggered_at=?, updated_at=?
                                WHERE id=?
                            """, (cur, now_iso(), now_iso(), alert["id"]))
                            triggered += 1
                    if triggered:
                        logger.info(f"🔔 {triggered} alert(s) triggered")

                    # 3. Hourly cleanup
                    if tick % 120 == 0:  # every hour (120 × 30s)
                        from utils.helpers import now_iso
                        execute("""
                            DELETE FROM blacklisted_tokens
                            WHERE revoked_at < datetime('now', '-2 days')
                        """)
                        # Clean old price history (keep last 7 days)
                        execute("""
                            DELETE FROM price_history
                            WHERE recorded_at < datetime('now', '-7 days')
                        """)
                        logger.info("🧹 Hourly cleanup done")

            except Exception as e:
                logger.error(f"Scheduler error: {e}")

    t = threading.Thread(target=run, daemon=True, name="apexfx-scheduler")
    t.start()
    logger.info("✅ Background scheduler thread started")
