"""
APEX FX — Input Validators
"""
import re


def validate_email(email: str) -> bool:
    pattern = r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_password(password: str) -> str | None:
    """Return error message or None if valid."""
    if not password:
        return "Password is required"
    if len(password) < 6:
        return "Password must be at least 6 characters"
    if len(password) > 128:
        return "Password too long"
    return None
