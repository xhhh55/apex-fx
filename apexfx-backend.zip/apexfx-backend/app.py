"""
╔══════════════════════════════════════════════════════════════╗
║              APEX FX — BACKEND API SERVER                    ║
║         Flask + SQLite + JWT + Real Prices Cache             ║
╚══════════════════════════════════════════════════════════════╝

Architecture:
  /api/auth     → register, login, logout, me
  /api/users    → profile, preferences
  /api/favorites → CRUD favorites
  /api/alerts   → price alerts + auto-trigger check
  /api/portfolio → virtual trades CRUD
  /api/reviews  → broker reviews
  /api/prices   → live prices (ECB cache)
  /api/brokers  → brokers list + detail
  /api/news     → market news
  /api/analytics→ market stats
  /api/admin    → admin panel

Run:  python app.py
Docs: http://localhost:5000/api/docs
"""

import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, jsonify, g
from config import Config
from database import init_db
from middleware.auth import auth_middleware
from middleware.rate_limit import rate_limiter
from api.auth import auth_bp
from api.users import users_bp
from api.favorites import favorites_bp
from api.alerts import alerts_bp
from api.portfolio import portfolio_bp
from api.reviews import reviews_bp
from api.prices import prices_bp
from api.brokers import brokers_bp
from api.news import news_bp
from api.analytics import analytics_bp
from api.admin import admin_bp
from utils.scheduler import start_scheduler
import logging

# ── Logging ──────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# ── App Factory ───────────────────────────────────
def create_app(config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config:
        app.config.update(config)

    # Manual CORS headers (no flask-cors needed)
    @app.after_request
    def add_cors_headers(response):
        response.headers["Access-Control-Allow-Origin"]  = "*"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        response.headers["Access-Control-Expose-Headers"]= "X-Total-Count, X-Rate-Limit"
        return response

    @app.before_request
    def handle_preflight():
        from flask import request, Response
        if request.method == "OPTIONS":
            r = Response()
            r.headers["Access-Control-Allow-Origin"]  = "*"
            r.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            r.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
            return r, 204

    # Init DB
    with app.app_context():
        init_db()
        logger.info("✅ Database initialized")

    # Middleware
    auth_middleware(app)
    rate_limiter(app)

    # Blueprints
    app.register_blueprint(auth_bp,      url_prefix="/api/auth")
    app.register_blueprint(users_bp,     url_prefix="/api/users")
    app.register_blueprint(favorites_bp, url_prefix="/api/favorites")
    app.register_blueprint(alerts_bp,    url_prefix="/api/alerts")
    app.register_blueprint(portfolio_bp, url_prefix="/api/portfolio")
    app.register_blueprint(reviews_bp,   url_prefix="/api/reviews")
    app.register_blueprint(prices_bp,    url_prefix="/api/prices")
    app.register_blueprint(brokers_bp,   url_prefix="/api/brokers")
    app.register_blueprint(news_bp,      url_prefix="/api/news")
    app.register_blueprint(analytics_bp, url_prefix="/api/analytics")
    app.register_blueprint(admin_bp,     url_prefix="/api/admin")

    # ── Global error handlers ──
    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": "Bad Request", "message": str(e)}), 400

    @app.errorhandler(401)
    def unauthorized(e):
        return jsonify({"error": "Unauthorized", "message": "Authentication required"}), 401

    @app.errorhandler(403)
    def forbidden(e):
        return jsonify({"error": "Forbidden", "message": "Access denied"}), 403

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not Found", "message": "Resource not found"}), 404

    @app.errorhandler(429)
    def rate_limit_exceeded(e):
        return jsonify({"error": "Too Many Requests", "message": "Rate limit exceeded"}), 429

    @app.errorhandler(500)
    def server_error(e):
        logger.exception("Internal server error")
        return jsonify({"error": "Internal Server Error", "message": "Something went wrong"}), 500

    # ── Health check ──
    @app.route("/api/health")
    def health():
        from database import get_db
        db = get_db()
        user_count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        return jsonify({
            "status": "ok",
            "version": "2.0.0",
            "service": "APEX FX API",
            "database": "connected",
            "users": user_count,
        })

    # ── API Docs (simple) ──
    @app.route("/api/docs")
    def api_docs():
        docs = {
            "service": "APEX FX Backend API",
            "version": "2.0.0",
            "base_url": "/api",
            "authentication": "Bearer JWT token in Authorization header",
            "endpoints": {
                "auth": {
                    "POST /auth/register": "Register new user",
                    "POST /auth/login":    "Login, returns JWT",
                    "POST /auth/logout":   "Invalidate session",
                    "GET  /auth/me":       "Current user info (🔒)",
                    "PUT  /auth/password": "Change password (🔒)",
                },
                "users": {
                    "GET  /users/profile":       "Get profile (🔒)",
                    "PUT  /users/profile":       "Update profile (🔒)",
                    "GET  /users/preferences":   "Get preferences (🔒)",
                    "PUT  /users/preferences":   "Update preferences (🔒)",
                    "GET  /users/stats":         "User statistics (🔒)",
                    "DELETE /users/account":     "Delete account (🔒)",
                },
                "favorites": {
                    "GET    /favorites":        "List favorites (🔒)",
                    "POST   /favorites":        "Add broker to favorites (🔒)",
                    "DELETE /favorites/:id":    "Remove favorite (🔒)",
                    "GET    /favorites/export": "Export favorites as PDF/CSV (🔒)",
                },
                "alerts": {
                    "GET    /alerts":        "List all alerts (🔒)",
                    "POST   /alerts":        "Create price alert (🔒)",
                    "PUT    /alerts/:id":    "Update alert (🔒)",
                    "DELETE /alerts/:id":    "Delete alert (🔒)",
                    "POST   /alerts/check":  "Manually trigger check (🔒)",
                },
                "portfolio": {
                    "GET    /portfolio":             "Portfolio summary (🔒)",
                    "GET    /portfolio/trades":      "Open trades (🔒)",
                    "POST   /portfolio/trades":      "Open new trade (🔒)",
                    "DELETE /portfolio/trades/:id":  "Close trade (🔒)",
                    "GET    /portfolio/history":     "Closed trades history (🔒)",
                    "GET    /portfolio/stats":       "Performance stats (🔒)",
                    "POST   /portfolio/reset":       "Reset portfolio (🔒)",
                },
                "reviews": {
                    "GET  /reviews/:broker_id":      "Get broker reviews",
                    "POST /reviews/:broker_id":      "Submit review (🔒)",
                    "PUT  /reviews/:id":             "Edit review (🔒)",
                    "DELETE /reviews/:id":           "Delete review (🔒)",
                },
                "prices": {
                    "GET /prices":         "All live prices",
                    "GET /prices/:pair":   "Single pair price",
                    "GET /prices/history": "Price history (24h)",
                },
                "brokers": {
                    "GET /brokers":       "All brokers",
                    "GET /brokers/:id":   "Single broker detail",
                    "GET /brokers/search": "Search brokers",
                },
                "news": {
                    "GET /news":           "Latest forex news",
                    "GET /news/:id":       "Single news item",
                    "GET /news/calendar":  "Economic calendar",
                },
                "analytics": {
                    "GET /analytics/market":   "Market overview stats",
                    "GET /analytics/rankings": "Broker rankings",
                },
                "admin": {
                    "GET /admin/users":         "All users (🔑 admin)",
                    "GET /admin/stats":         "System stats (🔑 admin)",
                    "PUT /admin/users/:id/ban": "Ban user (🔑 admin)",
                },
            },
            "legend": {
                "🔒": "Requires user authentication",
                "🔑": "Requires admin role",
            }
        }
        return jsonify(docs)

    return app


# ── Entry point ───────────────────────────────────
app = create_app()

if __name__ == "__main__":
    logger.info("🚀 Starting APEX FX API Server...")
    logger.info("📖 Docs: http://localhost:5000/api/docs")
    logger.info("❤️  Health: http://localhost:5000/api/health")

    # Start background scheduler (price alerts, cache refresh)
    start_scheduler(app)

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True,
        use_reloader=False,  # False when scheduler is running
    )
