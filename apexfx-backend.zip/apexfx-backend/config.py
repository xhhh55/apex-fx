"""
APEX FX — Configuration
"""
import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class Config:
    # ── Security ──────────────────────────────────
    SECRET_KEY = os.environ.get("SECRET_KEY", secrets.token_hex(32))
    JWT_SECRET  = os.environ.get("JWT_SECRET",  secrets.token_hex(32))
    JWT_ALGORITHM        = "HS256"
    JWT_ACCESS_EXPIRES   = 60 * 60 * 24        # 24 hours  (seconds)
    JWT_REFRESH_EXPIRES  = 60 * 60 * 24 * 30   # 30 days

    # ── Database ───────────────────────────────────
    DATABASE_PATH = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "apexfx.db"))

    # ── Passwords ─────────────────────────────────
    BCRYPT_ROUNDS = 12

    # ── Rate Limiting ──────────────────────────────
    RATE_LIMIT_GLOBAL     = 300   # requests per minute per IP
    RATE_LIMIT_AUTH       = 10    # auth endpoints per minute per IP
    RATE_LIMIT_PORTFOLIO  = 60    # portfolio ops per minute

    # ── Portfolio ──────────────────────────────────
    PORTFOLIO_STARTING_BALANCE = 100_000.0  # USD
    PORTFOLIO_MAX_LOTS         = 100.0
    PORTFOLIO_MIN_LOTS         = 0.01
    PORTFOLIO_MAX_OPEN_TRADES  = 20

    # ── Alerts ─────────────────────────────────────
    MAX_ALERTS_PER_USER = 20
    ALERT_CHECK_INTERVAL = 30  # seconds

    # ── Prices Cache ───────────────────────────────
    PRICES_CACHE_TTL   = 30    # seconds
    PRICES_ECB_URL     = "https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,AUD,CAD,CHF,NZD"
    PRICES_HISTORY_POINTS = 288  # 24h at 5-min intervals

    # ── CORS ───────────────────────────────────────
    CORS_ORIGINS = ["*"]  # Restrict in production

    # ── Pagination ────────────────────────────────
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE     = 100

    # ── Reviews ───────────────────────────────────
    MAX_REVIEWS_PER_USER_PER_BROKER = 1

    # ── Admin ─────────────────────────────────────
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@apexfx.com")
